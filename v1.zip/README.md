# ergDJ

A music app for Erg Rowing that motivates you through curated Spotify playlists.
